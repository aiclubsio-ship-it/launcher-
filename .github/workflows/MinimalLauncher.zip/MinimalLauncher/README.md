# Minimal Launcher (yellow & black)

## Build the APK
1. Install Android Studio (Koala or newer; bundled JDK 17 is fine).
2. File > Open > select this folder. Let Gradle sync (internet needed once).
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
   Output: app/build/outputs/apk/debug/app-debug.apk

## Install
Copy the APK to the phone, open it, allow "Install unknown apps" when asked.
Or via USB debugging: adb install app-debug.apk

## Set as default launcher
Press Home > choose "Minimal Launcher" > Always.
Or Settings > Apps > Default apps > Home app. The in-app Settings page also has a shortcut button.

## Use
Long-press the home screen (or tap SETTINGS) to configure.
