package com.minimal.launcher

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, PICKER }

val BgColor = Color(0xFF0A0A0A)
val Mustard = Color(0xFFF5B800)
val SoftGrey = Color(0xFFB5B5B5)

class MainActivity : ComponentActivity() {
    private val refresh = mutableIntStateOf(0)
    private val screen = mutableStateOf(Screen.HOME)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { LauncherApp(refresh.intValue, screen.value) { screen.value = it } }
    }

    override fun onResume() {
        super.onResume()
        refresh.intValue++ // re-query apps (installs/uninstalls) and refresh clock
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed -> always return to the home screen
        if (intent.hasCategory(Intent.CATEGORY_HOME)) screen.value = Screen.HOME
    }
}

@Composable
fun LauncherApp(refresh: Int, screen: Screen, setScreen: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by remember { ctx.prefsFlow() }.collectAsState(initial = null)
    val p = prefs
    if (p == null) { Box(Modifier.fillMaxSize().background(BgColor)); return }

    val accent = if (p.yellow) Mustard else Color.White
    val save: ((Prefs) -> Prefs) -> Unit = { f -> scope.launch { ctx.updatePrefs(f) } }

    BackHandler {
        when (screen) {
            Screen.PICKER -> setScreen(Screen.SETTINGS)
            Screen.SETTINGS -> setScreen(Screen.HOME)
            Screen.HOME -> Unit // a launcher never exits
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent, onPrimary = Color.Black,
            background = BgColor, surface = BgColor,
            onBackground = Color.White, onSurface = Color.White,
        )
    ) {
        Box(Modifier.fillMaxSize().background(BgColor)) {
            when (screen) {
                Screen.HOME -> HomeScreen(p, refresh, accent) { setScreen(Screen.SETTINGS) }
                Screen.SETTINGS -> SettingsScreen(p, save, { setScreen(Screen.PICKER) }) { setScreen(Screen.HOME) }
                Screen.PICKER -> PickerScreen(p, save) { setScreen(Screen.SETTINGS) }
            }
        }
    }
}
