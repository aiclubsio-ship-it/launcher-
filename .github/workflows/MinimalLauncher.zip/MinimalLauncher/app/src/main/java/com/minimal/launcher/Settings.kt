@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.minimal.launcher

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("‹ BACK", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, letterSpacing = 2.sp,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onBack() }.padding(10.dp))
        Spacer(Modifier.weight(1f))
        Text(title, color = SoftGrey, fontSize = 13.sp, letterSpacing = 3.sp)
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, onDone: (Int) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(Modifier.padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White); Text("${v.roundToInt()}", color = SoftGrey)
        }
        Slider(v, { v = it }, valueRange = range.first.toFloat()..range.last.toFloat(),
            onValueChangeFinished = { onDone(v.roundToInt()) })
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun ChoiceRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(label, color = Color.White)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, o ->
                FilterChip(
                    selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(p: Prefs, save: ((Prefs) -> Prefs) -> Unit, onPicker: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmReset by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Header("SETTINGS", onBack)
        Button(onClick = onPicker, modifier = Modifier.fillMaxWidth()) { Text("Add / remove apps (${p.apps.size} selected)") }
        Spacer(Modifier.height(12.dp))
        SliderRow("Icon size", p.iconSize, 56..144) { v -> save { it.copy(iconSize = v) } }
        SliderRow("Icon spacing", p.spacing, 8..64) { v -> save { it.copy(spacing = v) } }
        SliderRow("Clock size", p.clockSize, 40..120) { v -> save { it.copy(clockSize = v) } }
        SwitchRow("Show app names", p.showNames) { v -> save { it.copy(showNames = v) } }
        SwitchRow("Show date", p.showDate) { v -> save { it.copy(showDate = v) } }
        ChoiceRow("Icon arrangement", listOf("2 columns", "Row", "List"), p.layout) { v -> save { it.copy(layout = v) } }
        ChoiceRow("Accent colour", listOf("Yellow", "White"), if (p.yellow) 0 else 1) { v -> save { it.copy(yellow = v == 0) } }
        ChoiceRow("Clock position", listOf("Top", "Middle", "Bottom"), p.clockV) { v -> save { it.copy(clockV = v) } }
        ChoiceRow("Clock alignment", listOf("Left", "Center", "Right"), p.clockH) { v -> save { it.copy(clockH = v) } }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { openDefaultHomeSettings(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Set as default launcher") }
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Reset settings") }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("Reset settings?") },
        text = { Text("Look and layout return to defaults. Your selected apps are kept.") },
        confirmButton = { TextButton({ confirmReset = false; scope.launch { ctx.resetPrefs() } }) { Text("Reset") } },
        dismissButton = { TextButton({ confirmReset = false }) { Text("Cancel") } }
    )
}

@Composable
fun PickerScreen(p: Prefs, save: ((Prefs) -> Prefs) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    var all by remember { mutableStateOf<List<AppInfo>?>(null) }
    LaunchedEffect(Unit) {
        val px = with(density) { 48.dp.roundToPx() }
        all = withContext(Dispatchers.Default) { loadApps(ctx, null, px) }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
        Header("CHOOSE APPS · ${p.apps.size}", onBack)
        val list = all
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.pkg }) { app ->
                val checked = app.pkg in p.apps
                val toggle = {
                    save { cur -> cur.copy(apps = if (app.pkg in cur.apps) cur.apps - app.pkg else cur.apps + app.pkg) }
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { toggle() }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Image(app.icon, app.label, Modifier.size(48.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                    Checkbox(checked, { toggle() })
                }
            }
        }
    }
}
