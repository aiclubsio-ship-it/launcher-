package com.minimal.launcher

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("launcher_prefs")

data class Prefs(
    val apps: List<String> = emptyList(),
    val iconSize: Int = 88,
    val clockSize: Int = 72,
    val spacing: Int = 24,
    val showNames: Boolean = true,
    val showDate: Boolean = true,
    val yellow: Boolean = true,
    val layout: Int = 0,   // 0 = two columns, 1 = row, 2 = list
    val clockV: Int = 0,   // 0 = top, 1 = middle, 2 = bottom
    val clockH: Int = 0,   // 0 = left, 1 = center, 2 = right
)

private object K {
    val apps = stringPreferencesKey("apps")
    val icon = intPreferencesKey("icon")
    val clock = intPreferencesKey("clock")
    val spacing = intPreferencesKey("spacing")
    val names = booleanPreferencesKey("names")
    val date = booleanPreferencesKey("date")
    val yellow = booleanPreferencesKey("yellow")
    val layout = intPreferencesKey("layout")
    val clockV = intPreferencesKey("clockV")
    val clockH = intPreferencesKey("clockH")
}

private fun Preferences.toPrefs(): Prefs {
    val d = Prefs()
    return Prefs(
        apps = this[K.apps]?.split("\n")?.filter { it.isNotBlank() } ?: d.apps,
        iconSize = this[K.icon] ?: d.iconSize,
        clockSize = this[K.clock] ?: d.clockSize,
        spacing = this[K.spacing] ?: d.spacing,
        showNames = this[K.names] ?: d.showNames,
        showDate = this[K.date] ?: d.showDate,
        yellow = this[K.yellow] ?: d.yellow,
        layout = this[K.layout] ?: d.layout,
        clockV = this[K.clockV] ?: d.clockV,
        clockH = this[K.clockH] ?: d.clockH,
    )
}

fun Context.prefsFlow(): Flow<Prefs> =
    store.data.catch { emit(emptyPreferences()) }.map { it.toPrefs() }

suspend fun Context.updatePrefs(f: (Prefs) -> Prefs) {
    store.edit { m ->
        val p = f(m.toPrefs())
        m[K.apps] = p.apps.joinToString("\n")
        m[K.icon] = p.iconSize
        m[K.clock] = p.clockSize
        m[K.spacing] = p.spacing
        m[K.names] = p.showNames
        m[K.date] = p.showDate
        m[K.yellow] = p.yellow
        m[K.layout] = p.layout
        m[K.clockV] = p.clockV
        m[K.clockH] = p.clockH
    }
}

/** Resets look & feel settings. Selected apps are kept to avoid surprise data loss. */
suspend fun Context.resetPrefs() = updatePrefs { Prefs(apps = it.apps) }
