@file:OptIn(ExperimentalLayoutApi::class)

package com.minimal.launcher

import android.text.format.DateFormat
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(p: Prefs, refresh: Int, accent: Color, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { p.iconSize.dp.roundToPx() }.coerceIn(64, 512)
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }

    LaunchedEffect(p.apps, px, refresh) {
        apps = withContext(Dispatchers.Default) {
            loadApps(ctx, p.apps.toSet(), px).sortedBy { p.apps.indexOf(it.pkg) }
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) }
    ) {
        Column(
            Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = if (p.clockV == 1) Arrangement.Center else Arrangement.Top
        ) {
            if (p.clockV != 2) { Clock(p, refresh, accent); Spacer(Modifier.height(32.dp)) }
            val boxMod = if (p.clockV == 1) Modifier.fillMaxWidth() else Modifier.weight(1f).fillMaxWidth()
            Box(boxMod, contentAlignment = Alignment.Center) {
                if (p.apps.isEmpty()) {
                    Text("Long-press anywhere to add apps", color = SoftGrey, fontSize = 14.sp, textAlign = TextAlign.Center)
                } else {
                    FlowRow(
                        maxItemsInEachRow = when (p.layout) { 0 -> 2; 1 -> 4; else -> 1 },
                        horizontalArrangement = Arrangement.spacedBy(p.spacing.dp, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(p.spacing.dp),
                    ) { apps.forEach { a -> AppTile(a, p) { launchApp(ctx, a.pkg) } } }
                }
            }
            if (p.clockV == 2) { Spacer(Modifier.height(32.dp)); Clock(p, refresh, accent) }
        }
        Text(
            "SETTINGS", color = SoftGrey, fontSize = 11.sp, letterSpacing = 3.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(8.dp))
                .clickable { onSettings() }.padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun AppTile(app: AppInfo, p: Prefs, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable { onClick() }.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, app.label, Modifier.size(p.iconSize.dp), contentScale = ContentScale.Fit)
        if (p.showNames) {
            Spacer(Modifier.height(8.dp))
            Text(
                app.label, color = SoftGrey, fontSize = 13.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = (p.iconSize + 24).dp)
            )
        }
    }
}

@Composable
fun Clock(p: Prefs, refresh: Int, accent: Color) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(refresh) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L) // wakes once per minute
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", Locale.getDefault()))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = when (p.clockH) { 0 -> Alignment.Start; 1 -> Alignment.CenterHorizontally; else -> Alignment.End }
    ) {
        Text(time, color = accent, fontSize = p.clockSize.sp, fontWeight = FontWeight.Light)
        if (p.showDate) Text(date.uppercase(), color = SoftGrey, fontSize = 13.sp, letterSpacing = 2.sp)
    }
}
